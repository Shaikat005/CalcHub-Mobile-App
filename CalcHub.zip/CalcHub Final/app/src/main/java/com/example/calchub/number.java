package com.example.calchub;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class number extends AppCompatActivity {

    WebView webView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number);
        getWindow().setStatusBarColor(ContextCompat.getColor(number.this,R.color.orange));

        webView=findViewById(R.id.webView);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://www.rapidtables.com/convert/number/base-converter.html");
    }

    public void onBackPressed() {

        // Check if the WebView can go back
        if (webView.canGoBack()) {

            // If there's history, go back
            webView.goBack();
        } else {

            // If no history, call the default back press behavior (close the app)
            super.onBackPressed();
        }

    }
}