package com.example.calchub;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class age1 extends AppCompatActivity {

    private EditText dateOfBirthInput;
    private Button calculateButton;
    private TextView ageOutput;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_age1);

        dateOfBirthInput = findViewById(R.id.date_of_birth_input);
        calculateButton = findViewById(R.id.calculate_button);
        ageOutput = findViewById(R.id.age_output);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dateOfBirthString = dateOfBirthInput.getText().toString();

                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Calendar dateOfBirthCalendar = Calendar.getInstance();
                    dateOfBirthCalendar.setTime(dateFormat.parse(dateOfBirthString));

                    Calendar todayCalendar = Calendar.getInstance();
                    int ageInYears = todayCalendar.get(Calendar.YEAR) - dateOfBirthCalendar.get(Calendar.YEAR);

                    // Calculate months and days (optional)
                    int monthDiff = todayCalendar.get(Calendar.MONTH) - dateOfBirthCalendar.get(Calendar.MONTH);
                    int daysInMonth = Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH);
                    int daysDiff = todayCalendar.get(Calendar.DAY_OF_MONTH) - dateOfBirthCalendar.get(Calendar.DAY_OF_MONTH);

                    if (monthDiff < 0 || (monthDiff == 0 && daysDiff < 0)) {
                        ageInYears--;
                    }

                    String ageText = "Your age is: " + ageInYears + " years";

                    // Add months and days output (optional)
                    if (monthDiff >= 0 && daysDiff >= 0) {
                        ageText += " and " + monthDiff + " months and " + daysDiff + " days";
                    }

                    ageOutput.setText(ageText);
                } catch (ParseException e) {
                    ageOutput.setText("Invalid date format. Please try again.");
                }
            }
        });
    }
}