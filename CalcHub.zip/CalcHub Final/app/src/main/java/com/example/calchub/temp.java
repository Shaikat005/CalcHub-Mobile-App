package com.example.calchub;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class temp extends AppCompatActivity {

    WebView web;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp);
        getWindow().setStatusBarColor(ContextCompat.getColor(temp.this,R.color.orange));

        web= findViewById(R.id.web);
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("https://www.rapidtables.com/convert/temperature/index.html");
    }

    public void onBackPressed() {

        // Check if the WebView can go back
        if (web.canGoBack()) {

            // If there's history, go back
            web.goBack();
        } else {

            // If no history, call the default back press behavior (close the app)
            super.onBackPressed();
        }

    }
}