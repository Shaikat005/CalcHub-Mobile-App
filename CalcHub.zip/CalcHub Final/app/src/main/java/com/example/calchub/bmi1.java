package com.example.calchub;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.DecimalFormat;

public class bmi1 extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi1);

        TextView ResultTxt;
        EditText Editweight,Editheight,Editheight2;
        Button ResultBtn;
        LinearLayout Backgrnd;

        Editweight=findViewById(R.id.Editweight);
        Editheight=findViewById(R.id.Editheight);
        Editheight2=findViewById(R.id.Editheight2);
        ResultTxt=findViewById(R.id.ResultTxt);
        ResultBtn=findViewById(R.id.ResultBtn);

        ResultBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int wt=Integer.parseInt(Editweight.getText().toString());
                int ht=Integer.parseInt(Editheight.getText().toString());
                int ht2=Integer.parseInt(Editheight2.getText().toString());

                int totalIn=ht*12;
                double totalCm=totalIn*2.53;
                double totalM=totalCm/100;
                double bmi=wt/(totalM*totalM);

                DecimalFormat decimalFormat=new DecimalFormat("#.##");
                if(bmi>25){
                    ResultTxt.setText("You're Overweight.You need to reduce your weight by "+decimalFormat.format(((bmi-25)*(totalM*totalM)))+" kg");
                }else if(bmi<18){
                    ResultTxt.setText("You're Underweight. You need to gain weight "+decimalFormat.format(((18-bmi)*(totalM*totalM)))+" kg");
                }else{
                    ResultTxt.setText("You're healthy.");
                }
            }
        });

    }
}