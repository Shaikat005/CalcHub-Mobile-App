package com.example.calchub;





import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuPresenter;
import androidx.core.content.ContextCompat;

import android.os.Bundle;

public class simple extends AppCompatActivity {

    Button btnAdd, btnSub, btnMul, btnDiv;
    EditText edtTxt1, edtTxt2;
    TextView TxtView;
    Float num1,num2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple);
        getWindow().setStatusBarColor(ContextCompat.getColor(simple.this, R.color.orange));

        btnAdd = findViewById(R.id.btnAdd);
        btnSub = findViewById(R.id.btnSub);
        btnMul = findViewById(R.id.btnMul);
        btnDiv = findViewById(R.id.btnDiv);

        edtTxt1 = findViewById(R.id.edtTxt1);
        edtTxt2 = findViewById(R.id.edtTxt2);

        TxtView = findViewById(R.id.TxtView);



    }
    // Calculate and display the result
    public  void calculateAndDisplay(View view) {
        try {
            if (edtTxt1.getText().toString().equals("") && edtTxt2.getText().toString().equals("")) {
                Toast.makeText(this, "Enter Number!!!", Toast.LENGTH_LONG).show();
                return;
            }
            Float num1 = Float.parseFloat(edtTxt1.getText().toString());
            Float num2 = Float.parseFloat(edtTxt2.getText().toString());


            if (view.getId() == R.id.btnAdd) {
                TxtView.setText("Answer = " + (num1 + num2));
            } else if (view.getId() == R.id.btnSub) {
                TxtView.setText("Answer = " + (num1 - num2));
            } else if (view.getId() == R.id.btnMul) {
                TxtView.setText("Answer = " + (num1 * num2));
            } else if (view.getId() == R.id.btnDiv) {
                TxtView.setText("Answer = " + (num1 / num2));
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid input! Enter valid numbers.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "An error occurred: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}